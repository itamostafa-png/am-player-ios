// Adds AM Player's native Swift files to the Capacitor Xcode project (App target)
const fs = require('fs');
const xcode = require('xcode');
const file = 'ios/App/App.xcodeproj/project.pbxproj';
const proj = xcode.project(file);
proj.parseSync();
const group = proj.findPBXGroupKey({ name: 'App' }) || proj.findPBXGroupKey({ path: 'App' });
const target = proj.getFirstTarget().uuid;
const existing = fs.readFileSync(file, 'utf8');
for (const f of ['VlcPlayerPlugin.swift', 'MainViewController.swift']) {
  if (existing.includes(f)) continue;
  proj.addSourceFile(f, { target }, group);
}
fs.writeFileSync(file, proj.writeSync().replace(/ explicitFileType = undefined;/g, '').replace(/ includeInIndex = 0;/g, ''));
console.log('added native files to Xcode project');
