import Foundation
import UIKit
import AVFoundation
import Capacitor
import MobileVLCKit

/// Plays any format (MKV, AVI, MP4...) with VLC inside AM Player.
/// The video is drawn in a view placed *behind* the (transparent) web view,
/// so the app's own HTML controls stay on top.
@objc(VlcPlayerPlugin)
public class VlcPlayerPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "VlcPlayerPlugin"
    public let jsName = "VlcPlayer"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "play", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "pause", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "resume", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "seek", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stop", returnType: CAPPluginReturnPromise)
    ]

    private var player: VLCMediaPlayer?
    private var videoView: UIView?
    private var timer: Timer?
    private var lastState = ""

    private func setupView() {
        guard let web = self.bridge?.webView else { return }
        if videoView == nil {
            let v = UIView(frame: web.bounds)
            v.backgroundColor = .black
            v.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            v.isUserInteractionEnabled = false
            web.insertSubview(v, at: 0)
            videoView = v
        }
        videoView?.isHidden = false
        web.isOpaque = false
        web.backgroundColor = .clear
        web.scrollView.backgroundColor = .clear
    }

    @objc func play(_ call: CAPPluginCall) {
        guard let s = call.getString("url"), let url = URL(string: s) else {
            call.reject("bad url"); return
        }
        let start = call.getDouble("start") ?? 0
        DispatchQueue.main.async {
            try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try? AVAudioSession.sharedInstance().setActive(true)
            self.setupView()
            self.player?.stop()
            let p = VLCMediaPlayer()
            p.drawable = self.videoView
            let media = VLCMedia(url: url)
            media.addOption(":network-caching=3000")
            if start > 1 { media.addOption(":start-time=\(Int(start))") }
            p.media = media
            self.player = p
            self.lastState = ""
            p.play()
            self.startTimer()
            call.resolve()
        }
    }

    @objc func pause(_ call: CAPPluginCall) {
        DispatchQueue.main.async { self.player?.pause(); self.emit(); call.resolve() }
    }

    @objc func resume(_ call: CAPPluginCall) {
        DispatchQueue.main.async { self.player?.play(); self.emit(); call.resolve() }
    }

    @objc func seek(_ call: CAPPluginCall) {
        let t = call.getDouble("time") ?? 0
        DispatchQueue.main.async {
            if let p = self.player {
                p.time = VLCTime(int: Int32(max(0, t) * 1000))
            }
            call.resolve()
        }
    }

    @objc func stop(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            self.timer?.invalidate(); self.timer = nil
            self.player?.stop()
            self.player = nil
            self.videoView?.isHidden = true
            call.resolve()
        }
    }

    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in self?.emit() }
    }

    private func stateName(_ p: VLCMediaPlayer) -> String {
        switch p.state {
        case .opening: return "opening"
        case .buffering: return p.isPlaying ? "playing" : "buffering"
        case .playing: return "playing"
        case .paused: return "paused"
        case .ended: return "ended"
        case .error: return "error"
        case .stopped: return "stopped"
        default: return p.isPlaying ? "playing" : "opening"
        }
    }

    private func emit() {
        guard let p = player else { return }
        let state = stateName(p)
        let time = Double(p.time.intValue) / 1000.0
        let len = Double(p.media?.length.intValue ?? 0) / 1000.0
        notifyListeners("state", data: ["state": state, "time": time, "duration": len])
        if state == "ended" || state == "error" { timer?.invalidate(); timer = nil }
        lastState = state
    }
}
