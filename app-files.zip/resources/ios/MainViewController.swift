import UIKit
import Capacitor

/// Registers AM Player's own native plugins.
class MainViewController: CAPBridgeViewController {
    override open func capacitorDidLoad() {
        bridge?.registerPluginInstance(VlcPlayerPlugin())
    }
}
