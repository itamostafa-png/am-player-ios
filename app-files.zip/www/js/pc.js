/* PC extras: fit to window, mouse wheel, mouse control in the player, fullscreen.
   Disabled on TVs (Tizen / webOS). */
(function () {
  var isTV = !!window.tizen || /Web0S|webOS|Tizen/i.test(navigator.userAgent);
  if (isTV || window.IS_MOBILE) return;
  document.body.className += ' pc';

  /* --- the UI is designed at 1920x1080, scale it to the window --- */
  var h = document.documentElement.style;
  h.width = '100%'; h.height = '100%'; h.background = '#08080b';
  var b = document.body.style;
  b.position = 'absolute'; b.left = '0'; b.top = '0'; b.transformOrigin = '0 0';
  // In the Windows app the window zoom is set by main.js (sharper text, no transform);
  // here we only center the 1920x1080 canvas. In a normal browser we scale with a transform.
  var electron = /Electron/i.test(navigator.userAgent);
  function fit() {
    var s = electron ? 1 : Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
    b.transform = electron ? '' : 'scale(' + s + ')';
    b.left = Math.max(0, (window.innerWidth - 1920 * s) / 2) + 'px';
    b.top = Math.max(0, (window.innerHeight - 1080 * s) / 2) + 'px';
  }
  window.addEventListener('resize', fit);
  fit();

  /* --- mouse wheel scrolling --- */
  function wheelable(id, onScroll) {
    var el = document.getElementById(id);
    el.addEventListener('wheel', function (e) {
      e.preventDefault();
      el.scrollTop += e.deltaY;
      if (onScroll && el.scrollTop + el.clientHeight > el.scrollHeight - 600) onScroll();
    }, { passive: false });
  }
  wheelable('categories');
  wheelable('items', function () { App.loadMore(); });
  wheelable('episodes');
  wheelable('server-list');

  /* --- right click = back --- */
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); App.back(); });

  /* --- fullscreen --- */
  function toggleFullscreen() {
    var d = document;
    if (!d.fullscreenElement) { if (d.documentElement.requestFullscreen) d.documentElement.requestFullscreen(); }
    else if (d.exitFullscreen) d.exitFullscreen();
  }
  document.addEventListener('keydown', function (e) {
    var typing = document.activeElement && document.activeElement.tagName === 'INPUT';
    if (e.keyCode === 122 || (e.keyCode === 70 && !typing)) { e.preventDefault(); e.stopPropagation(); toggleFullscreen(); }
    if (e.keyCode === 32 && App.screen() === 'player') { e.preventDefault(); e.stopPropagation(); Player.handleKey(Keys.ENTER); }
    // Delete key removes an item from Continue Watching
    if (e.keyCode === 46 && !typing) {
      var cur = Nav.current();
      if (cur && cur.className.indexOf('card') !== -1) App.removeContinue(parseInt(cur.getAttribute('data-i'), 10));
    }
  }, true);

  /* --- mouse in the player --- */
  var video = document.getElementById('video');
  var clickT = null;
  video.addEventListener('click', function () {
    clearTimeout(clickT);
    clickT = setTimeout(function () { Player.handleKey(Keys.ENTER); }, 250);
  });
  video.addEventListener('dblclick', function () { clearTimeout(clickT); toggleFullscreen(); });
  video.addEventListener('wheel', function (e) {
    e.preventDefault();
    video.volume = Math.max(0, Math.min(1, video.volume - e.deltaY / 1000));
    showVolume();
  }, { passive: false });
  document.getElementById('player-screen').addEventListener('mousemove', function () { Player.showOsd(); });

  var bar = document.querySelector('.osd-bar');
  bar.style.cursor = 'pointer';
  bar.style.height = '16px';
  bar.addEventListener('click', function (e) {
    var r = bar.getBoundingClientRect();
    if (video.duration && isFinite(video.duration)) video.currentTime = (e.clientX - r.left) / r.width * video.duration;
  });

  var volT;
  function showVolume() {
    var el = document.getElementById('toast');
    el.textContent = '🔊 ' + Math.round(video.volume * 100) + '%';
    el.className = 'toast show';
    clearTimeout(volT); volT = setTimeout(function () { el.className = 'toast'; }, 1200);
  }
})();
