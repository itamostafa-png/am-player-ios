/* Player: HLS for live (native or hls.js) + direct playback for movies/episodes.
   On-screen controls: previous / -10s / play-pause / +10s / next / stop */
var Player = (function () {
  var video, hls = null, osdTimer = null, progressTimer = null, saveTimer = null, osdVisible = false;
  var state = { isLive: false, playlist: null, index: 0, startAt: 0, onProgress: null, onStop: null };
  var SEEK = 10, defaultStop = null;

  function el(id) { return document.getElementById(id); }
  function destroyHls() { if (hls) { try { hls.destroy(); } catch (e) {} hls = null; } }
  function showLoading(on) { el('player-loading').className = 'spinner' + (on ? ' show' : ''); }
  function showError(msg) {
    var e = el('player-error');
    e.style.display = msg ? 'block' : 'none';
    e.textContent = msg || '';
  }

  function fmt(s) {
    if (!isFinite(s) || s < 0) return '--:--';
    s = Math.floor(s);
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return (h ? h + ':' : '') + (m < 10 ? '0' : '') + m + ':' + (x < 10 ? '0' : '') + x;
  }

  function updateProgress() {
    if (state.isLive || !video.duration || !isFinite(video.duration)) {
      el('osd-progress').style.width = state.isLive ? '100%' : '0';
      el('osd-cur').textContent = state.isLive ? '● LIVE' : fmt(video.currentTime);
      el('osd-dur').textContent = '';
      return;
    }
    el('osd-progress').style.width = (video.currentTime / video.duration * 100) + '%';
    el('osd-cur').textContent = fmt(video.currentTime);
    el('osd-dur').textContent = fmt(video.duration);
  }

  function updatePlayIcon() {
    var paused = video.paused;
    el('ico-play').style.display = paused ? '' : 'none';
    el('ico-pause').style.display = paused ? 'none' : '';
  }

  function reportProgress() {
    if (state.isLive || !state.onProgress || !video.duration || !isFinite(video.duration)) return;
    state.onProgress(state.playlist[state.index], video.currentTime, video.duration, state.index, state.playlist);
  }

  function btn(act) { return el('player-controls').querySelector('[data-act="' + act + '"]'); }

  // which buttons make sense for this content
  function layoutButtons() {
    var many = state.playlist && state.playlist.length > 1;
    btn('prev').style.display = many ? '' : 'none';
    btn('next').style.display = many ? '' : 'none';
    btn('rew').style.display = state.isLive ? 'none' : '';
    btn('fwd').style.display = state.isLive ? 'none' : '';
  }

  function hideOsd() {
    osdVisible = false;
    el('player-osd').className = 'player-osd hidden';
    el('player-top').className = 'player-top hidden';
  }

  function showOsd(focusPlay) {
    var wasHidden = !osdVisible;
    osdVisible = true;
    el('player-osd').className = 'player-osd';
    el('player-top').className = 'player-top';
    updateProgress();
    if ((wasHidden || focusPlay) && window.Nav && !Nav.touch) Nav.focus(btn('play'));
    clearTimeout(osdTimer);
    osdTimer = setTimeout(function () { if (!video.paused) hideOsd(); }, 5000);
  }

  function seek(delta) {
    if (state.isLive || !video.duration) return;
    video.currentTime = Math.max(0, Math.min(video.duration - 1, video.currentTime + delta));
    updateProgress();
  }

  function step(dir) {
    if (!state.playlist || state.playlist.length < 2) return;
    reportProgress();
    var n = state.playlist.length;
    if (!state.isLive && (state.index + dir < 0 || state.index + dir >= n)) return; // no wrap for episodes
    state.index = (state.index + dir + n) % n;
    state.startAt = 0;
    playCurrent();
  }

  function toggle() { if (video.paused) video.play(); else video.pause(); }

  function action(act) {
    switch (act) {
      case 'play': toggle(); break;
      case 'rew': seek(-SEEK); break;
      case 'fwd': seek(SEEK); break;
      case 'prev': step(-1); break;
      case 'next': step(1); break;
      case 'stop': if (state.onStop) state.onStop(); break;
    }
    showOsd(false);
  }

  function load(url, fallbackUrl) {
    destroyHls();
    showError('');
    showLoading(true);
    video.removeAttribute('src');
    try { video.load(); } catch (e) {}

    var isHls = /\.m3u8(\?|$)/i.test(url);
    var native = video.canPlayType('application/vnd.apple.mpegurl') || video.canPlayType('application/x-mpegURL');

    if (isHls && !native && window.Hls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, maxBufferLength: 30 });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, function () { video.play(); });
      hls.on(Hls.Events.ERROR, function (ev, data) {
        if (!data.fatal) return;
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR && fallbackUrl) {
          var f = fallbackUrl; fallbackUrl = null; load(f, null);
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          hls.recoverMediaError();
        } else {
          showLoading(false); showError(t('cantPlay'));
        }
      });
    } else {
      video.src = url;
      video.onerror = function () {
        if (fallbackUrl) { var f = fallbackUrl; fallbackUrl = null; load(f, null); return; }
        showLoading(false);
        showError(t(state.isLive ? 'cantPlay' : 'cantPlayFile'));
      };
      var p = video.play();
      if (p && p.catch) p.catch(function () {});
    }
  }

  function playCurrent() {
    var item = state.playlist[state.index];
    el('osd-title').textContent = item.title;
    load(item.url, item.fallback);
    showOsd(true);
  }

  return {
    init: function () {
      video = el('video');
      video.preload = 'auto';
      video.addEventListener('playing', function () { showLoading(false); showError(''); updatePlayIcon(); });
      video.addEventListener('play', updatePlayIcon);
      video.addEventListener('pause', function () { updatePlayIcon(); showOsd(false); });
      video.addEventListener('waiting', function () { showLoading(true); });
      video.addEventListener('loadedmetadata', function () {
        // resume from where the viewer stopped (continue watching)
        if (state.startAt > 0 && video.duration && state.startAt < video.duration - 10) {
          try { video.currentTime = state.startAt; } catch (e) {}
        }
        state.startAt = 0;
      });
      video.addEventListener('ended', function () {
        reportProgress();
        if (!state.isLive && state.playlist && state.index < state.playlist.length - 1) {
          state.index++; playCurrent();
        }
      });
      // click / tap on the progress bar = jump there
      var bar = el('osd-bar');
      bar.addEventListener('click', function (e) {
        var r = bar.getBoundingClientRect();
        if (!state.isLive && video.duration && isFinite(video.duration)) {
          video.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * video.duration;
          updateProgress(); showOsd(false);
        }
      });
    },

    /* playlist: [{title, url, fallback, meta}] */
    open: function (playlist, index, isLive, opts) {
      opts = opts || {};
      state.playlist = playlist;
      state.index = index || 0;
      state.isLive = !!isLive;
      state.startAt = opts.startAt || 0;
      state.onProgress = opts.onProgress || null;
      state.onStop = opts.onStop || defaultStop;
      layoutButtons();
      clearInterval(progressTimer); clearInterval(saveTimer);
      progressTimer = setInterval(function () { if (osdVisible) updateProgress(); }, 1000);
      saveTimer = setInterval(reportProgress, 5000);
      playCurrent();
    },

    stop: function () {
      reportProgress();
      clearInterval(progressTimer); clearInterval(saveTimer);
      clearTimeout(osdTimer);
      destroyHls();
      try { video.pause(); video.removeAttribute('src'); video.load(); } catch (e) {}
      showLoading(false); showError('');
    },

    setDefaultStop: function (fn) { defaultStop = fn; },
    showOsd: showOsd,
    hideOsd: hideOsd,
    osdVisible: function () { return osdVisible; },
    action: action,
    toggle: toggle,

    /* remote keys while playing. Returns true when handled */
    handleKey: function (code) {
      // media keys always work
      switch (code) {
        case Keys.PLAY_PAUSE: toggle(); showOsd(false); return true;
        case Keys.PLAY: video.play(); showOsd(false); return true;
        case Keys.PAUSE: video.pause(); return true;
        case Keys.STOP: if (state.onStop) state.onStop(); return true;
        case Keys.FF: seek(SEEK * 3); showOsd(false); return true;
        case Keys.RW: seek(-SEEK * 3); showOsd(false); return true;
        case Keys.CH_UP: case Keys.PAGE_UP: step(1); return true;
        case Keys.CH_DOWN: case Keys.PAGE_DOWN: step(-1); return true;
      }
      if (!osdVisible) {
        // controls hidden: quick actions, then show the controls
        if (code === Keys.LEFT) { seek(-SEEK); showOsd(true); return true; }
        if (code === Keys.RIGHT) { seek(SEEK); showOsd(true); return true; }
        if (state.isLive && code === Keys.UP) { step(1); return true; }
        if (state.isLive && code === Keys.DOWN) { step(-1); return true; }
        if (code === Keys.ENTER || code === Keys.UP || code === Keys.DOWN) { showOsd(true); return true; }
        return false;
      }
      // controls visible: move between buttons, OK presses the button
      switch (code) {
        case Keys.LEFT: Nav.move('left'); showOsd(false); return true;
        case Keys.RIGHT: Nav.move('right'); showOsd(false); return true;
        case Keys.UP: Nav.move('up'); showOsd(false); return true;
        case Keys.DOWN: Nav.move('down'); showOsd(false); return true;
        case Keys.ENTER:
          var cur = Nav.current();
          if (cur && cur.getAttribute('data-act')) action(cur.getAttribute('data-act'));
          else if (cur && cur.id === 'btn-player-back' && state.onStop) state.onStop();
          else showOsd(false);
          return true;
      }
      return false;
    }
  };
})();
