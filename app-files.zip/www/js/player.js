/* Player: HLS for live (native or hls.js) + direct playback for movies/episodes.
   On-screen controls: previous / -10s / play-pause / +10s / next / stop */
var Player = (function () {
  var video, hls = null, osdTimer = null, progressTimer = null, saveTimer = null, osdVisible = false;
  var state = { isLive: false, playlist: null, index: 0, startAt: 0, onProgress: null, onStop: null };
  var SEEK = 10, defaultStop = null;

  function el(id) { return document.getElementById(id); }
  function destroyHls() { if (hls) { try { hls.destroy(); } catch (e) {} hls = null; } }
  function showLoading(on) { el('player-loading').className = 'spinner' + (on ? ' show' : ''); }
  function showError(msg) {
    var e = el('player-error');
    e.style.display = msg ? 'block' : 'none';
    e.textContent = msg || '';
  }

  function fmt(s) {
    if (!isFinite(s) || s < 0) return '--:--';
    s = Math.floor(s);
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return (h ? h + ':' : '') + (m < 10 ? '0' : '') + m + ':' + (x < 10 ? '0' : '') + x;
  }

  function updateProgress() {
    if (state.isLive || !video.duration || !isFinite(video.duration)) {
      el('osd-progress').style.width = state.isLive ? '100%' : '0';
      el('osd-cur').textContent = state.isLive ? '● LIVE' : fmt(video.currentTime);
      el('osd-dur').textContent = '';
      return;
    }
    el('osd-progress').style.width = (video.currentTime / video.duration * 100) + '%';
    el('osd-cur').textContent = fmt(video.currentTime);
    el('osd-dur').textContent = fmt(video.duration);
  }

  function updatePlayIcon() {
    var paused = video.paused;
    el('ico-play').style.display = paused ? '' : 'none';
    el('ico-pause').style.display = paused ? 'none' : '';
  }

  function reportProgress() {
    if (state.isLive || !state.onProgress || !video.duration || !isFinite(video.duration)) return;
    state.onProgress(state.playlist[state.index], video.currentTime, video.duration, state.index, state.playlist);
  }

  function btn(act) { return el('player-controls').querySelector('[data-act="' + act + '"]'); }

  // which buttons make sense for this content
  function layoutButtons() {
    var many = state.playlist && state.playlist.length > 1;
    btn('prev').style.display = many ? '' : 'none';
    btn('next').style.display = many ? '' : 'none';
    btn('rew').style.display = state.isLive ? 'none' : '';
    btn('fwd').style.display = state.isLive ? 'none' : '';
  }

  function hideOsd() {
    osdVisible = false;
    el('player-osd').className = 'player-osd hidden';
    el('player-top').className = 'player-top hidden';
  }

  function showOsd(focusPlay) {
    var wasHidden = !osdVisible;
    osdVisible = true;
    el('player-osd').className = 'player-osd';
    el('player-top').className = 'player-top';
    updateProgress();
    if ((wasHidden || focusPlay) && window.Nav && !Nav.touch) Nav.focus(btn('play'));
    clearTimeout(osdTimer);
    osdTimer = setTimeout(function () { if (!video.paused) hideOsd(); }, 5000);
  }

  function seek(delta) {
    if (state.isLive || !video.duration) return;
    video.currentTime = Math.max(0, Math.min(video.duration - 1, video.currentTime + delta));
    updateProgress();
  }

  function step(dir) {
    if (!state.playlist || state.playlist.length < 2) return;
    reportProgress();
    var n = state.playlist.length;
    if (!state.isLive && (state.index + dir < 0 || state.index + dir >= n)) return; // no wrap for episodes
    state.index = (state.index + dir + n) % n;
    state.startAt = 0;
    playCurrent();
  }

  function toggle() { if (video.paused) video.play(); else video.pause(); }

  function action(act) {
    switch (act) {
      case 'play': toggle(); break;
      case 'rew': seek(-SEEK); break;
      case 'fwd': seek(SEEK); break;
      case 'prev': step(-1); break;
      case 'next': step(1); break;
      case 'stop': if (state.onStop) state.onStop(); break;
    }
    showOsd(false);
  }

  var startTimer = null, stallTimer = null, started = false, curUrl = '';

  /* ---------- engines ----------
     <video> for everything, except on iPhone/iPad where movies & episodes (MKV, MP4...) are played
     by the built-in VLC engine (native plugin). The VLC picture is drawn behind the web page,
     so the same on-screen controls are used. */
  var videoEl = null, nativeEng, handlers = [];
  function on(name, fn) { handlers.push([name, fn]); videoEl.addEventListener(name, fn); }

  function makeNative(plugin) {
    var L = {}, st = { time: 0, duration: NaN, paused: true, ready: 0, state: '' }, metaSent = false;
    var root = document.documentElement;
    function fire(n) {
      var a = L[n] || [];
      for (var i = 0; i < a.length; i++) { try { a[i].call(eng, { type: n }); } catch (e) {} }
      if (n === 'error' && eng.onerror) eng.onerror();
    }
    var eng = {
      isNative: true, broken: false, onerror: null,
      addEventListener: function (n, f) { (L[n] = L[n] || []).push(f); },
      open: function (url, start) {
        st = { time: start || 0, duration: NaN, paused: false, ready: 0, state: 'opening' };
        metaSent = false;
        if (root.className.indexOf('native-video') === -1) root.className += ' native-video';
        var p = plugin.play({ url: url, start: start || 0 });
        if (p && p.then) p.then(null, function () { eng.broken = true; fire('error'); });
      },
      play: function () { st.paused = false; plugin.resume(); fire('play'); return { then: function () {}, catch: function () {} }; },
      pause: function () { st.paused = true; plugin.pause(); fire('pause'); },
      stop: function () {
        st.paused = true; st.state = '';
        root.className = root.className.replace(/\s*native-video/g, '');
        try { plugin.stop(); } catch (e) {}
      }
    };
    Object.defineProperty(eng, 'currentTime', {
      get: function () { return st.time; },
      set: function (v) { st.time = v; plugin.seek({ time: v }); }
    });
    Object.defineProperty(eng, 'duration', { get: function () { return st.duration; } });
    Object.defineProperty(eng, 'paused', { get: function () { return st.paused; } });
    Object.defineProperty(eng, 'readyState', { get: function () { return st.ready; } });
    plugin.addListener('state', function (d) {
      if (d.duration > 0) {
        st.duration = d.duration;
        if (!metaSent) { metaSent = true; fire('loadedmetadata'); }
      }
      if (d.state === 'playing') {
        st.time = d.time; st.ready = 4;
        if (st.state !== 'playing') { st.paused = false; fire('playing'); }
        fire('timeupdate');
      } else if (d.state === 'buffering' || d.state === 'opening') {
        if (st.state === 'playing') { st.ready = 1; fire('waiting'); }
      } else if (d.state === 'paused') {
        st.time = d.time;
      } else if (d.state === 'ended') {
        if (st.state !== 'ended') fire('ended');
      } else if (d.state === 'error') {
        if (st.state !== 'error') fire('error');
      }
      st.state = d.state;
    });
    for (var i = 0; i < handlers.length; i++) eng.addEventListener(handlers[i][0], handlers[i][1]);
    return eng;
  }

  function getNative() {
    if (nativeEng !== undefined) return nativeEng;
    nativeEng = null;
    try {
      var C = window.Capacitor;
      if (C && C.getPlatform && C.getPlatform() === 'ios') {
        var plugin = (C.Plugins && C.Plugins.VlcPlayer) || (C.registerPlugin ? C.registerPlugin('VlcPlayer') : null);
        if (plugin) nativeEng = makeNative(plugin);
      }
    } catch (e) { nativeEng = null; }
    return nativeEng;
  }

  function useNative(url) {
    if (/\.m3u8(\?|$)/i.test(url)) return null;   // live / HLS: Safari's own player is best
    var n = getNative();
    return n && !n.broken ? n : null;
  }

  function stopEngines() {
    try { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); } catch (e) {}
    if (nativeEng) nativeEng.stop();
    video = videoEl;
  }
  // auto-reconnect: when a video that was already playing breaks, reload it and continue from the same second
  var itemStarted = false, retries = 0, lastTime = 0, loadedUrl = '', loadedFallback = null;
  var MAX_RETRIES = 3, retryFrom = 0;

  // iPhone / iPad app (Capacitor) and Android app can hand the video to an external player
  function isIOSApp() { try { return !!(window.Capacitor && Capacitor.getPlatform && Capacitor.getPlatform() === 'ios'); } catch (e) { return false; } }
  function canExternal() { return false; } // everything plays inside AM Player
  function openExternal() {
    var item = state.playlist && state.playlist[state.index];
    if (!item) return;
    try { video.pause(); } catch (e) {}
    if (isIOSApp()) window.location.href = 'vlc-x-callback://x-callback-url/stream?url=' + encodeURIComponent(item.url);
    else if (window.AndroidApp && AndroidApp.openExternal) AndroidApp.openExternal(item.url, item.title || '');
  }
  function fileExt(u) { var m = /\.([a-z0-9]{2,4})(\?|$)/i.exec(u || ''); return m ? m[1].toUpperCase() : ''; }

  function failed(fallbackUrl) {
    clearTimeout(startTimer);
    clearTimeout(stallTimer);
    // it was playing fine before: this is a dropped connection, not a bad format -> reconnect and continue
    if (itemStarted && retries < MAX_RETRIES) {
      retries++;
      retryFrom = lastTime;
      if (!state.isLive) state.startAt = lastTime;
      var u = loadedUrl, f = loadedFallback;
      setTimeout(function () { load(u, f); }, 800 * retries);
      return;
    }
    if (fallbackUrl) { if (itemStarted && !state.isLive) state.startAt = lastTime; load(fallbackUrl, null); return; }
    showLoading(false);
    var ext = fileExt(curUrl);
    showError(t(state.isLive ? 'cantPlay' : 'cantPlayFile') + (ext && !state.isLive ? '  (' + ext + ')' : '') + (canExternal() ? '  ·  ' + t('tryExt') : ''));
    if (canExternal()) { showOsd(false); if (window.Nav && !Nav.touch) Nav.focus(el('btn-ext')); }
  }

  function load(url, fallbackUrl) {
    loadedUrl = url; loadedFallback = fallbackUrl;
    destroyHls();
    showError('');
    showLoading(true);
    curUrl = state.playlist && state.playlist[state.index] ? state.playlist[state.index].url : url;
    started = false;
    clearTimeout(startTimer);
    // if nothing starts within 20 s, try the other format instead of waiting forever
    var nat = useNative(url);
    startTimer = setTimeout(function () { if (!started) { try { video.pause(); } catch (e) {} failed(fallbackUrl); } }, nat ? 30000 : 20000);

    if (nat) {
      try { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); } catch (e) {}
      video = nat;
      var start = state.startAt || 0;
      state.startAt = 0;   // VLC starts at that second itself
      nat.onerror = function () { var f = fallbackUrl; fallbackUrl = null; failed(f); };
      nat.open(url, start);
      return;
    }
    if (video !== videoEl) stopEngines();
    video.removeAttribute('src');
    try { video.load(); } catch (e) {}

    var isHls = /\.m3u8(\?|$)/i.test(url);
    var native = video.canPlayType('application/vnd.apple.mpegurl') || video.canPlayType('application/x-mpegURL');

    if (isHls && !native && window.Hls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, maxBufferLength: 30 });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, function () { video.play(); });
      hls.on(Hls.Events.ERROR, function (ev, data) {
        if (!data.fatal) return;
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR && fallbackUrl) {
          var f = fallbackUrl; fallbackUrl = null; failed(f);
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          hls.recoverMediaError();
        } else {
          failed(fallbackUrl);
        }
      });
    } else {
      video.src = url;
      video.onerror = function () { var f = fallbackUrl; fallbackUrl = null; failed(f); };
      var p = video.play();
      if (p && p.catch) p.catch(function () {});
    }
  }

  function playCurrent() {
    resetItem();
    var item = state.playlist[state.index];
    el('osd-title').textContent = item.title;
    el('btn-ext').style.display = canExternal() ? '' : 'none';
    el('ext-label').textContent = isIOSApp() ? 'VLC' : t('extPlayer');
    // iPhone/iPad cannot play MKV/AVI at all: go straight to the server's HLS version
    var n = isIOSApp() ? getNative() : null;
    if (isIOSApp() && (!n || n.broken) && item.fallback && /\.(mkv|avi|wmv|flv)(\?|$)/i.test(item.url)) load(item.fallback, null);
    else load(item.url, item.fallback);
    showOsd(true);
  }

  function resetItem() { itemStarted = false; retries = 0; lastTime = 0; retryFrom = 0; }

  return {
    init: function () {
      videoEl = el('video');
      video = videoEl;
      video.preload = 'auto';
      on('playing', function () {
        started = true; itemStarted = true;
        clearTimeout(startTimer); clearTimeout(stallTimer);
        showLoading(false); showError(''); updatePlayIcon();
      });
      on('timeupdate', function () {
        if (video.currentTime > 0) lastTime = video.currentTime;
        // after a minute of smooth playback, allow fresh reconnect attempts again
        if (retries && started && video.currentTime > retryFrom + 60) retries = 0;
      });
      on('play', updatePlayIcon);
      on('pause', function () { updatePlayIcon(); showOsd(false); });
      on('waiting', function () {
        showLoading(true);
        // stuck buffering for 30 s while playing -> reconnect
        clearTimeout(stallTimer);
        if (started) stallTimer = setTimeout(function () { if (video.readyState < 3) failed(loadedFallback); }, 30000);
      });
      on('loadedmetadata', function () {
        // resume from where the viewer stopped (continue watching)
        if (state.startAt > 0 && video.duration && state.startAt < video.duration - 10) {
          try { video.currentTime = state.startAt; } catch (e) {}
        }
        state.startAt = 0;
      });
      on('ended', function () {
        reportProgress();
        if (!state.isLive && state.playlist && state.index < state.playlist.length - 1) {
          state.index++; playCurrent();
        }
      });
      // click / tap on the progress bar = jump there
      var bar = el('osd-bar');
      bar.addEventListener('click', function (e) {
        var r = bar.getBoundingClientRect();
        if (!state.isLive && video.duration && isFinite(video.duration)) {
          video.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * video.duration;
          updateProgress(); showOsd(false);
        }
      });
    },

    /* playlist: [{title, url, fallback, meta}] */
    open: function (playlist, index, isLive, opts) {
      opts = opts || {};
      state.playlist = playlist;
      state.index = index || 0;
      state.isLive = !!isLive;
      state.startAt = opts.startAt || 0;
      state.onProgress = opts.onProgress || null;
      state.onStop = opts.onStop || defaultStop;
      layoutButtons();
      clearInterval(progressTimer); clearInterval(saveTimer);
      progressTimer = setInterval(function () { if (osdVisible) updateProgress(); }, 1000);
      saveTimer = setInterval(reportProgress, 5000);
      playCurrent();
    },

    stop: function () {
      reportProgress();
      clearInterval(progressTimer); clearInterval(saveTimer);
      clearTimeout(osdTimer);
      clearTimeout(startTimer);
      clearTimeout(stallTimer);
      resetItem();
      destroyHls();
      stopEngines();
      showLoading(false); showError('');
    },

    setDefaultStop: function (fn) { defaultStop = fn; },
    showOsd: showOsd,
    hideOsd: hideOsd,
    osdVisible: function () { return osdVisible; },
    action: action,
    openExternal: openExternal,
    toggle: toggle,

    /* remote keys while playing. Returns true when handled */
    handleKey: function (code) {
      // media keys always work
      switch (code) {
        case Keys.PLAY_PAUSE: toggle(); showOsd(false); return true;
        case Keys.PLAY: video.play(); showOsd(false); return true;
        case Keys.PAUSE: video.pause(); return true;
        case Keys.STOP: if (state.onStop) state.onStop(); return true;
        case Keys.FF: seek(SEEK * 3); showOsd(false); return true;
        case Keys.RW: seek(-SEEK * 3); showOsd(false); return true;
        case Keys.CH_UP: case Keys.PAGE_UP: step(1); return true;
        case Keys.CH_DOWN: case Keys.PAGE_DOWN: step(-1); return true;
      }
      if (!osdVisible) {
        // controls hidden: quick actions, then show the controls
        if (code === Keys.LEFT) { seek(-SEEK); showOsd(true); return true; }
        if (code === Keys.RIGHT) { seek(SEEK); showOsd(true); return true; }
        if (state.isLive && code === Keys.UP) { step(1); return true; }
        if (state.isLive && code === Keys.DOWN) { step(-1); return true; }
        if (code === Keys.ENTER || code === Keys.UP || code === Keys.DOWN) { showOsd(true); return true; }
        return false;
      }
      // controls visible: move between buttons, OK presses the button
      switch (code) {
        case Keys.LEFT: Nav.move('left'); showOsd(false); return true;
        case Keys.RIGHT: Nav.move('right'); showOsd(false); return true;
        case Keys.UP: Nav.move('up'); showOsd(false); return true;
        case Keys.DOWN: Nav.move('down'); showOsd(false); return true;
        case Keys.ENTER:
          var cur = Nav.current();
          if (cur && cur.getAttribute('data-act')) action(cur.getAttribute('data-act'));
          else if (cur && cur.id === 'btn-player-back' && state.onStop) state.onStop();
          else showOsd(false);
          return true;
      }
      return false;
    }
  };
})();
