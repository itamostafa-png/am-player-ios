/* Player: HLS for live (native or hls.js) + direct playback for movies/episodes */
var Player = (function () {
  var video, hls = null, osdTimer = null, progressTimer = null, saveTimer = null;
  var state = { isLive: false, playlist: null, index: 0, startAt: 0, onProgress: null };

  function el(id) { return document.getElementById(id); }
  function destroyHls() { if (hls) { try { hls.destroy(); } catch (e) {} hls = null; } }
  function showLoading(on) { el('player-loading').className = 'spinner' + (on ? ' show' : ''); }
  function showError(msg) {
    var e = el('player-error');
    e.style.display = msg ? 'block' : 'none';
    e.textContent = msg || '';
  }

  function fmt(s) {
    if (!isFinite(s) || s < 0) return '--:--';
    s = Math.floor(s);
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return (h ? h + ':' : '') + (m < 10 ? '0' : '') + m + ':' + (x < 10 ? '0' : '') + x;
  }

  function updateProgress() {
    if (state.isLive || !video.duration || !isFinite(video.duration)) {
      el('osd-progress').style.width = state.isLive ? '100%' : '0';
      el('osd-time').textContent = state.isLive ? '● LIVE' : fmt(video.currentTime);
      return;
    }
    el('osd-progress').style.width = (video.currentTime / video.duration * 100) + '%';
    el('osd-time').textContent = fmt(video.currentTime) + ' / ' + fmt(video.duration);
  }

  function reportProgress() {
    if (state.isLive || !state.onProgress || !video.duration || !isFinite(video.duration)) return;
    state.onProgress(state.playlist[state.index], video.currentTime, video.duration, state.index, state.playlist);
  }

  function showOsd() {
    el('player-osd').className = 'player-osd';
    el('player-top').className = 'player-top';
    clearTimeout(osdTimer);
    osdTimer = setTimeout(function () {
      el('player-osd').className = 'player-osd hidden';
      el('player-top').className = 'player-top hidden';
    }, 4000);
  }

  function load(url, fallbackUrl) {
    destroyHls();
    showError('');
    showLoading(true);
    video.removeAttribute('src');
    try { video.load(); } catch (e) {}

    var isHls = /\.m3u8(\?|$)/i.test(url);
    var native = video.canPlayType('application/vnd.apple.mpegurl') || video.canPlayType('application/x-mpegURL');

    if (isHls && !native && window.Hls && Hls.isSupported()) {
      hls = new Hls({ enableWorker: true, maxBufferLength: 30 });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, function () { video.play(); });
      hls.on(Hls.Events.ERROR, function (ev, data) {
        if (!data.fatal) return;
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR && fallbackUrl) {
          var f = fallbackUrl; fallbackUrl = null; load(f, null);
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          hls.recoverMediaError();
        } else {
          showLoading(false); showError(t('cantPlay'));
        }
      });
    } else {
      video.src = url;
      video.onerror = function () {
        if (fallbackUrl) { var f = fallbackUrl; fallbackUrl = null; load(f, null); return; }
        showLoading(false);
        showError(t(state.isLive ? 'cantPlay' : 'cantPlayFile'));
      };
      var p = video.play();
      if (p && p.catch) p.catch(function () {});
    }
  }

  function playCurrent() {
    var item = state.playlist[state.index];
    el('osd-title').textContent = item.title;
    load(item.url, item.fallback);
    showOsd();
  }

  return {
    init: function () {
      video = el('video');
      video.addEventListener('playing', function () { showLoading(false); showError(''); });
      video.addEventListener('waiting', function () { showLoading(true); });
      video.addEventListener('loadedmetadata', function () {
        // resume from where the viewer stopped (continue watching)
        if (state.startAt > 0 && video.duration && state.startAt < video.duration - 10) {
          try { video.currentTime = state.startAt; } catch (e) {}
        }
        state.startAt = 0;
      });
      video.addEventListener('ended', function () {
        reportProgress();
        if (!state.isLive && state.playlist && state.index < state.playlist.length - 1) {
          state.index++; playCurrent();
        }
      });
    },

    /* playlist: [{title, url, fallback, meta}] */
    open: function (playlist, index, isLive, opts) {
      opts = opts || {};
      state.playlist = playlist;
      state.index = index || 0;
      state.isLive = !!isLive;
      state.startAt = opts.startAt || 0;
      state.onProgress = opts.onProgress || null;
      clearInterval(progressTimer); clearInterval(saveTimer);
      progressTimer = setInterval(updateProgress, 1000);
      saveTimer = setInterval(reportProgress, 5000);
      playCurrent();
    },

    stop: function () {
      reportProgress();
      clearInterval(progressTimer); clearInterval(saveTimer);
      destroyHls();
      try { video.pause(); video.removeAttribute('src'); video.load(); } catch (e) {}
      showLoading(false); showError('');
    },

    showOsd: showOsd,

    handleKey: function (code) {
      showOsd();
      switch (code) {
        case Keys.ENTER: case Keys.PLAY_PAUSE:
          if (video.paused) video.play(); else video.pause(); return true;
        case Keys.PLAY: video.play(); return true;
        case Keys.PAUSE: video.pause(); return true;
        case Keys.RIGHT: case Keys.FF:
          if (!state.isLive && video.duration) video.currentTime = Math.min(video.duration - 1, video.currentTime + 15);
          return true;
        case Keys.LEFT: case Keys.RW:
          if (!state.isLive) video.currentTime = Math.max(0, video.currentTime - 15);
          return true;
        case Keys.UP: case Keys.CH_UP: case Keys.PAGE_UP:
          if (state.playlist.length > 1) { reportProgress(); state.index = (state.index + 1) % state.playlist.length; playCurrent(); }
          return true;
        case Keys.DOWN: case Keys.CH_DOWN: case Keys.PAGE_DOWN:
          if (state.playlist.length > 1) { reportProgress(); state.index = (state.index - 1 + state.playlist.length) % state.playlist.length; playCurrent(); }
          return true;
      }
      return false;
    }
  };
})();
