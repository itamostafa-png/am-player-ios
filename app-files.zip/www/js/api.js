/* Xtream Codes API client — ES5 so it runs on older TVs (Tizen 2.4+ / webOS 3+) */
var XtreamAPI = (function () {
  var creds = null;

  function normalizeUrl(url) {
    url = (url || '').trim();
    if (!/^https?:\/\//i.test(url)) url = 'http://' + url;
    return url.replace(/\/+$/, '');
  }

  // iPhone / iPad app: send requests through iOS itself (no web CORS / mixed-content limits)
  function nativeHttp() {
    var C = window.Capacitor;
    if (!C || !C.Plugins || !C.Plugins.CapacitorHttp) return null;
    if (C.isNativePlatform && !C.isNativePlatform()) return null;
    return C.Plugins.CapacitorHttp;
  }

  function parseBody(data) {
    if (data && typeof data === 'object') return data;
    return JSON.parse(data);
  }

  function request(url, timeout) {
    var http = nativeHttp();
    if (http) {
      return http.get({
        url: url,
        headers: { 'User-Agent': navigator.userAgent, 'Accept': 'application/json, text/plain, */*' },
        responseType: 'text',
        connectTimeout: timeout || 30000,
        readTimeout: timeout || 30000
      }).then(function (res) {
        if (res.status >= 200 && res.status < 300) {
          try { return parseBody(res.data); } catch (e) { throw new Error('errBad'); }
        }
        var er = new Error('errHttp'); er.extra = res.status; throw er;
      }, function (e) {
        var msg = String((e && e.message) || '');
        throw new Error(/timed? ?out/i.test(msg) ? 'errTimeout' : 'errNet');
      });
    }
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.timeout = timeout || 30000;
      xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
          try { resolve(JSON.parse(xhr.responseText)); }
          catch (e) { reject(new Error('errBad')); }
        } else {
          var er = new Error('errHttp'); er.extra = xhr.status; reject(er);
        }
      };
      xhr.onerror = function () { reject(new Error('errNet')); };
      xhr.ontimeout = function () { reject(new Error('errTimeout')); };
      xhr.send();
    });
  }

  function api(action, params, timeout) {
    var u = creds.url + '/player_api.php?username=' + encodeURIComponent(creds.username) +
      '&password=' + encodeURIComponent(creds.password);
    if (action) u += '&action=' + action;
    if (params) for (var k in params) if (params.hasOwnProperty(k) && params[k] !== undefined && params[k] !== null) {
      u += '&' + k + '=' + encodeURIComponent(params[k]);
    }
    return request(u, timeout);
  }

  function toArray(data) {
    if (!data) return [];
    if (Object.prototype.toString.call(data) === '[object Array]') return data;
    var arr = [];
    for (var k in data) if (data.hasOwnProperty(k)) arr.push(data[k]);
    return arr;
  }

  return {
    login: function (url, username, password) {
      creds = { url: normalizeUrl(url), username: username.trim(), password: password.trim() };
      return api(null).then(function (res) {
        if (!res || !res.user_info || res.user_info.auth === 0 || res.user_info.auth === '0') {
          throw new Error('errAuth');
        }
        if (res.user_info.status && res.user_info.status !== 'Active') {
          var er = new Error('errStatus'); er.extra = res.user_info.status; throw er;
        }
        creds.info = res;
        return res;
      });
    },
    getCreds: function () { return creds; },

    // type: live | movie | series
    getCategories: function (type) {
      var action = { live: 'get_live_categories', movie: 'get_vod_categories', series: 'get_series_categories' }[type];
      return api(action).then(toArray);
    },
    getItems: function (type, categoryId) {
      var action = { live: 'get_live_streams', movie: 'get_vod_streams', series: 'get_series' }[type];
      // the full list (no category) can be big, give it more time
      return api(action, categoryId ? { category_id: categoryId } : null, categoryId ? 30000 : 120000).then(toArray);
    },
    getSeriesInfo: function (seriesId) {
      return api('get_series_info', { series_id: seriesId });
    },
    getVodInfo: function (vodId) {
      return api('get_vod_info', { vod_id: vodId });
    },

    liveUrl: function (streamId, format) {
      return creds.url + '/live/' + encodeURIComponent(creds.username) + '/' +
        encodeURIComponent(creds.password) + '/' + streamId + '.' + (format || 'm3u8');
    },
    movieUrl: function (streamId, ext) {
      return creds.url + '/movie/' + encodeURIComponent(creds.username) + '/' +
        encodeURIComponent(creds.password) + '/' + streamId + '.' + (ext || 'mp4');
    },
    episodeUrl: function (episodeId, ext) {
      return creds.url + '/series/' + encodeURIComponent(creds.username) + '/' +
        encodeURIComponent(creds.password) + '/' + episodeId + '.' + (ext || 'mp4');
    },
    toArray: toArray
  };
})();
