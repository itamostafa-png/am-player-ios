/* Translations — English is the default, Arabic is optional */
var I18N = {
  en: {
    home: 'Home', back: 'Back', live: 'Live TV', movies: 'Movies', series: 'Series',
    continue: 'Continue Watching', servers: 'Servers', addServer: 'Add Server',
    serverName: 'Server name (optional)', url: 'Server URL  e.g. http://example.com:8080',
    username: 'Username', password: 'Password', save: 'Save & Connect',
    connect: 'Connect', del: 'Delete', confirmDel: 'Press again to delete', active: 'Connected',
    search: 'Search', all: 'All', favorites: 'Favorites', empty: 'Nothing here', noResults: 'No results',
    season: 'Season', ep: 'E', expires: 'Expires', unlimited: 'Unlimited', connections: 'Connections',
    fill: 'Please fill in URL, username and password', pressBack: 'Press back again to exit',
    favAdded: 'Added to favorites', favRemoved: 'Removed from favorites', noEpisodes: 'No episodes available',
    langName: 'العربية', play: 'Play', resume: 'Resume', fromStart: 'Play from start', addFav: 'Add to favorites', inFav: 'In favorites',
    director: 'Director', cast: 'Cast', daysLeft: 'days left', expired: 'Expired',
    errAuth: 'Wrong username or password', errStatus: 'Subscription status: ', errNet: 'Cannot reach the server, check the URL',
    errTimeout: 'Server took too long to respond', errBad: 'Invalid response from server', errHttp: 'Server error: ',
    cantPlay: 'This channel cannot be played', cantPlayFile: 'This file cannot be played (format may not be supported)'
  },
  ar: {
    home: 'الرئيسية', back: 'رجوع', live: 'البث المباشر', movies: 'الأفلام', series: 'المسلسلات',
    continue: 'كمّل مشاهدة', servers: 'السيرفرات', addServer: 'إضافة سيرفر',
    serverName: 'اسم السيرفر (اختياري)', url: 'رابط السيرفر  http://example.com:8080',
    username: 'Username', password: 'Password', save: 'حفظ واتصال',
    connect: 'اتصال', del: 'حذف', confirmDel: 'دوس تاني للحذف', active: 'متصل',
    search: 'بحث', all: 'الكل', favorites: 'المفضلة', empty: 'مفيش محتوى هنا', noResults: 'مفيش نتائج',
    season: 'الموسم', ep: 'ح', expires: 'ينتهي', unlimited: 'غير محدود', connections: 'الاتصالات',
    fill: 'اكتب الرابط واليوزر والباسورد', pressBack: 'دوس رجوع تاني للخروج',
    favAdded: 'اتضافت للمفضلة', favRemoved: 'اتشالت من المفضلة', noEpisodes: 'مفيش حلقات متاحة',
    langName: 'English', play: 'تشغيل', resume: 'كمّل', fromStart: 'من الأول', addFav: 'أضف للمفضلة', inFav: 'في المفضلة',
    director: 'إخراج', cast: 'بطولة', daysLeft: 'يوم متبقي', expired: 'منتهي',
    errAuth: 'اليوزر أو الباسورد غلط', errStatus: 'حالة الاشتراك: ', errNet: 'مش قادر أوصل للسيرفر، اتأكد من الرابط',
    errTimeout: 'السيرفر اتأخر في الرد', errBad: 'رد غير صالح من السيرفر', errHttp: 'خطأ من السيرفر: ',
    cantPlay: 'مش قادر أشغل القناة دي', cantPlayFile: 'مش قادر أشغل الملف ده (ممكن الصيغة مش مدعومة)'
  }
};

var Lang = (function () {
  var cur = 'en';
  try { cur = localStorage.getItem('lang') || 'en'; } catch (e) {}
  if (!I18N[cur]) cur = 'en';

  function apply() {
    var html = document.documentElement;
    html.setAttribute('lang', cur);
    html.setAttribute('dir', cur === 'ar' ? 'rtl' : 'ltr');
    var els = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < els.length; i++) els[i].textContent = t(els[i].getAttribute('data-i18n'));
    els = document.querySelectorAll('[data-i18n-ph]');
    for (i = 0; i < els.length; i++) els[i].setAttribute('placeholder', t(els[i].getAttribute('data-i18n-ph')));
    var l = document.getElementById('lang-label');
    if (l) l.textContent = t('langName');
  }

  return {
    get: function () { return cur; },
    toggle: function () {
      cur = cur === 'en' ? 'ar' : 'en';
      try { localStorage.setItem('lang', cur); } catch (e) {}
      apply();
    },
    apply: apply
  };
})();

/* t('key') or t('errStatus', 'Expired') -> translated text; unknown keys are returned as-is */
function t(key, extra) {
  var d = I18N[Lang.get()];
  var s = d.hasOwnProperty(key) ? d[key] : (I18N.en.hasOwnProperty(key) ? I18N.en[key] : key);
  return extra !== undefined ? s + extra : s;
}
