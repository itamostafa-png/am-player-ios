/* App logic: screens, servers, browsing, continue watching, remote control */
(function () {
  var CHUNK = 60;
  var SECTION = { live: 'live', movie: 'movies', series: 'series' };
  var ICON = {
    live: '<svg viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 3l4 3 4-3"/></svg>',
    movie: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16"/></svg>',
    series: '<svg viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M6 4h12"/></svg>'
  };

  var app = {
    screen: null, history: [],
    servers: [], activeId: null, info: null,
    type: null, items: [], allItems: [], rendered: 0, selectedCat: null,
    cache: {}, req: 0, movie: null, series: null, lastBack: 0
  };

  /* ---------- helpers ---------- */
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function bgUrl(u) { return u ? ' style="background-image:url(\'' + esc(u).replace(/'/g, '%27') + '\')"' : ''; }
  function loader(on) { $('loader').className = 'loader' + (on ? ' show' : ''); }
  var toastT;
  function toast(msg) {
    var el = $('toast'); el.textContent = msg; el.className = 'toast show';
    clearTimeout(toastT); toastT = setTimeout(function () { el.className = 'toast'; }, 3000);
  }
  function errText(e) { return t(e.message, e.extra); }
  function load(k, def) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? def : v; } catch (e) { return def; } }
  function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function activeServer() {
    for (var i = 0; i < app.servers.length; i++) if (app.servers[i].id === app.activeId) return app.servers[i];
    return null;
  }
  function serverLabel(s) { return s.name || s.url.replace(/^https?:\/\//, ''); }

  /* ---------- screens ---------- */
  var TITLES = {
    add: function () { return t('addServer'); },
    servers: function () { return t('servers'); },
    pair: function () { return t('pairBtn'); },
    home: function () { var s = activeServer(); return s ? serverLabel(s) : ''; },
    browse: function () { return t(SECTION[app.type]); },
    series: function () { return t('series'); },
    movie: function () { return t('movies'); }
  };

  function show(name, push) {
    if (push && app.screen && app.screen !== name) app.history.push({ screen: app.screen, focus: Nav.current() });
    var all = document.querySelectorAll('.screen');
    for (var i = 0; i < all.length; i++) all[i].className = 'screen';
    $(name + '-screen').className = 'screen active';
    $('topbar').className = name === 'player' ? 'hidden' : '';
    $('btn-back').style.display = name === 'home' ? 'none' : '';
    if (name !== 'pair') stopPair();
    $('statusbar').className = (name === 'player' || name === 'add' || !app.info) ? 'hidden' : '';
    $('bar-title').textContent = TITLES[name] ? TITLES[name]() : '';
    app.screen = name;
  }

  function back() {
    if (app.screen === 'player') { Player.stop(); }
    var prev = app.history.pop();
    if (!prev) { tryExit(); return; }
    show(prev.screen, false);
    if (prev.screen === 'browse' && (app.selectedCat === '__cw' || app.selectedCat === '__fav')) { refreshSpecialList(prev.focus); return; }
    if (prev.screen === 'servers') renderServers();
    if (prev.screen === 'movie') refreshMovieButtons();
    if (prev.focus && document.body.contains(prev.focus)) Nav.focus(prev.focus); else Nav.reset();
  }

  function goHome() {
    if (app.screen === 'player') Player.stop();
    if (!app.info) { app.history = []; openServers(); return; }
    app.history = [];
    show('home', false);
    Nav.reset(document.querySelector('.tile'));
  }

  function tryExit() {
    var now = Date.now();
    if (now - app.lastBack < 2000) {
      try { if (window.tizen) { tizen.application.getCurrentApplication().exit(); return; } } catch (e) {}
      try { if (window.webOS && webOS.platformBack) { webOS.platformBack(); return; } } catch (e) {}
      try { if (window.AndroidApp) { AndroidApp.exit(); return; } } catch (e) {}
      window.close();
    } else {
      app.lastBack = now;
      toast(t('pressBack'));
    }
  }

  /* ---------- servers ---------- */
  function openAdd() {
    $('in-name').value = ''; $('in-url').value = ''; $('in-user').value = ''; $('in-pass').value = '';
    $('login-msg').textContent = '';
    show('add', app.screen !== null);
    Nav.reset($('in-name'));
  }

  function saveServer() {
    var url = $('in-url').value.trim(), user = $('in-user').value.trim(), pass = $('in-pass').value.trim();
    if (!url || !user || !pass) { $('login-msg').textContent = t('fill'); return; }
    $('login-msg').textContent = '';
    addServer($('in-name').value.trim(), url, user, pass, function (e) { $('login-msg').textContent = errText(e); });
  }

  function addServer(name, url, user, pass, onFail) {
    loader(true);
    XtreamAPI.login(url, user, pass).then(function (res) {
      loader(false);
      var existing = null;
      for (var i = 0; i < app.servers.length; i++) {
        if (app.servers[i].url === url && app.servers[i].user === user) existing = app.servers[i];
      }
      if (!existing) {
        existing = { id: 's' + Date.now(), url: url, user: user, pass: pass, name: name || '' };
        app.servers.push(existing);
      } else {
        existing.pass = pass;
        if (name) existing.name = name;
      }
      save('servers', app.servers);
      setActive(existing, res);
    }, function (e) { loader(false); if (onFail) onFail(e); });
  }

  /* ---------- add a server from a phone / computer ----------
     The TV shows a code + QR. The web page (add.html) sends the server details to a
     short-lived ntfy.sh topic named after the code; the TV polls that topic. */
  var PAIR_PAGE = 'https://itamostafa-png.github.io/am-player-ios/add.html';
  var NTFY = window.NTFY_BASE || 'https://ntfy.sh/';
  var pair = null;

  function newCode() {
    var abc = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789', c = '';
    for (var i = 0; i < 8; i++) c += abc.charAt(Math.floor(Math.random() * abc.length));
    return c;
  }

  function decodePair(msg, code) {
    if (msg.indexOf('AMP1:') !== 0) return null;
    var raw = atob(msg.substring(5)), out = '';
    for (var i = 0; i < raw.length; i++) out += String.fromCharCode(raw.charCodeAt(i) ^ code.charCodeAt(i % code.length));
    return JSON.parse(decodeURIComponent(escape(out)));
  }

  function openPair() {
    stopPair();
    var code = newCode(), url = PAIR_PAGE + '#' + code;
    pair = { code: code, since: Math.floor(Date.now() / 1000) - 5, seen: {}, busy: false };
    $('pair-code').textContent = code.substring(0, 4) + '-' + code.substring(4);
    $('pair-url').textContent = PAIR_PAGE.replace(/^https?:\/\//, '');
    $('pair-status').textContent = t('pairWaiting');
    $('pair-status').className = 'pair-status';
    try {
      var qr = qrcode(0, 'M'); qr.addData(url); qr.make();
      $('pair-qr').innerHTML = qr.createSvgTag({ cellSize: 8, margin: 2, scalable: true });
    } catch (e) { $('pair-qr').innerHTML = ''; }
    show('pair', true);
    Nav.reset($('btn-pair-new'));
    pair.timer = setInterval(pollPair, 3000);
    pollPair();
  }

  function stopPair() { if (pair && pair.timer) clearInterval(pair.timer); pair = null; }

  function pollPair() {
    var p = pair;
    if (!p || p.busy) return;
    var xhr = new XMLHttpRequest();
    xhr.open('GET', NTFY + 'amplayer-' + p.code.toLowerCase() + '/json?poll=1&since=' + p.since, true);
    xhr.timeout = 10000;
    xhr.onload = function () {
      if (pair !== p || xhr.status !== 200) return;
      var lines = xhr.responseText.split('\n');
      for (var i = 0; i < lines.length; i++) {
        if (!lines[i]) continue;
        try {
          var m = JSON.parse(lines[i]);
          if (m.event !== 'message' || p.seen[m.id]) continue;
          p.seen[m.id] = 1;
          var d = decodePair(m.message || '', p.code);
          if (d && d.url && d.user && d.pass) { receivePair(d); return; }
        } catch (e) {}
      }
    };
    xhr.send();
  }

  function receivePair(d) {
    var p = pair; p.busy = true;
    $('pair-status').textContent = t('pairGot') + ' ' + (d.name || d.url);
    $('pair-status').className = 'pair-status ok';
    addServer(d.name, d.url, d.user, d.pass, function (e) {
      p.busy = false;
      $('pair-status').textContent = errText(e);
      $('pair-status').className = 'pair-status err';
    });
  }

  function connect(server, silent) {
    loader(true);
    XtreamAPI.login(server.url, server.user, server.pass).then(function (res) {
      loader(false);
      setActive(server, res);
    }, function (e) {
      loader(false);
      toast(serverLabel(server) + ': ' + errText(e));
      if (silent) { app.history = []; openServers(); }
    });
  }

  function setActive(server, res) {
    app.activeId = server.id;
    app.info = res.user_info;
    server.acc = { exp: res.user_info.exp_date, active: res.user_info.active_cons, max: res.user_info.max_connections };
    save('servers', app.servers);
    save('active', server.id);
    app.cache = {};
    renderStatus();
    goHome();
  }

  function openServers() {
    show('servers', app.screen !== null && app.screen !== 'servers');
    renderServers();
    Nav.reset($('server-list').querySelector('.connect') || $('btn-add'));
  }

  function renderServers() {
    var html = '';
    for (var i = 0; i < app.servers.length; i++) {
      var s = app.servers[i], cur = s.id === app.activeId && app.info;
      var acc = '';
      if (s.acc) {
        var exp = s.acc.exp ? new Date(parseInt(s.acc.exp, 10) * 1000).toLocaleDateString() : t('unlimited');
        acc = t('expires') + ': ' + exp + '  ·  ' + t('connections') + ': ' + (s.acc.active || 0) + ' / ' + (s.acc.max || '-');
      }
      html += '<div class="server' + (cur ? ' current' : '') + '">' +
        '<div class="server-info"><div class="server-name">' + esc(serverLabel(s)) +
        (cur ? '<span class="badge">' + t('active') + '</span>' : '') + '</div>' +
        '<div class="server-url">' + esc(s.url) + '  ·  ' + esc(s.user) + '</div>' +
        (acc ? '<div class="server-acc">' + esc(acc) + '</div>' : '') + '</div>' +
        '<button class="bar-btn focusable connect" data-id="' + s.id + '">' + t('connect') + '</button></div>';
    }
    $('server-list').innerHTML = html;
  }

  /* ---------- dialog (pick + confirm) ---------- */
  var dlg = null;
  function openDialog(opts) {
    // opts: { title, msg, items:[{label, value}], buttons:[{label, value, cls}], focus: value, onPick(value) }
    dlg = opts;
    dlg.prevFocus = Nav.current();
    $('dlg-title').textContent = opts.title || '';
    $('dlg-msg').textContent = opts.msg || '';
    var html = '';
    var items = opts.items || [];
    for (var i = 0; i < items.length; i++)
      html += '<button class="dlg-item focusable" data-dlg="' + esc(items[i].value) + '">' + esc(items[i].label) + '</button>';
    $('dlg-list').innerHTML = html;
    html = '';
    var btns = opts.buttons || [];
    for (i = 0; i < btns.length; i++)
      html += '<button class="btn focusable ' + (btns[i].cls || '') + '" data-dlg="' + esc(btns[i].value) + '">' + esc(btns[i].label) + '</button>';
    $('dlg-buttons').innerHTML = html;
    $('dialog').className = 'dialog';
    var f = opts.focus != null ? $('dialog').querySelector('[data-dlg="' + opts.focus + '"]') : null;
    Nav.reset(f || $('dialog').querySelector('.focusable'));
  }
  function closeDialog() {
    if (!dlg) return;
    var prev = dlg.prevFocus;
    dlg = null;
    $('dialog').className = 'dialog hidden';
    if (prev && document.body.contains(prev)) Nav.reset(prev); else Nav.reset();
  }
  function dialogPick(value) {
    var d = dlg;
    if (!d) return;
    closeDialog();
    if (value !== '__cancel' && d.onPick) d.onPick(value);
  }

  function askDeleteServer() {
    if (!app.servers.length) return;
    var items = [];
    for (var i = 0; i < app.servers.length; i++) items.push({ label: serverLabel(app.servers[i]), value: app.servers[i].id });
    openDialog({
      title: t('delWhich'), items: items,
      buttons: [{ label: t('cancel'), value: '__cancel', cls: 'btn-ghost' }],
      onPick: function (id) {
        var s = null;
        for (var j = 0; j < app.servers.length; j++) if (app.servers[j].id === id) s = app.servers[j];
        if (!s) return;
        openDialog({
          title: t('delConfirmTitle'), msg: '"' + serverLabel(s) + '"  ·  ' + t('delConfirmMsg'),
          buttons: [{ label: t('cancel'), value: '__cancel', cls: 'btn-ghost' }, { label: t('del'), value: 'yes', cls: 'btn-danger' }],
          focus: '__cancel',
          onPick: function () { deleteServer(id); }
        });
      }
    });
  }

  function deleteServer(id) {
    app.servers = app.servers.filter(function (s) { return s.id !== id; });
    save('servers', app.servers);
    try { localStorage.removeItem('cw_' + id); localStorage.removeItem('fav_' + id + '_live'); localStorage.removeItem('fav_' + id + '_movie'); localStorage.removeItem('fav_' + id + '_series'); } catch (e) {}
    if (id === app.activeId) { app.activeId = null; app.info = null; save('active', null); }
    if (!app.servers.length) { app.history = []; app.screen = null; openAdd(); return; }
    renderServers();
    show('servers', false);
    toast(t('deleted'));
    Nav.reset($('server-list').querySelector('.connect') || $('btn-add'));
  }

  /* ---------- bottom status bar ---------- */
  function renderStatus() {
    var s = activeServer(), u = app.info;
    if (!s || !u) return;
    $('sb-server').textContent = serverLabel(s);
    var exp = $('sb-exp');
    if (u.exp_date && u.exp_date !== 'null') {
      var d = new Date(parseInt(u.exp_date, 10) * 1000);
      var days = Math.ceil((d.getTime() - Date.now()) / 86400000);
      var txt;
      try { txt = d.toLocaleDateString(Lang.get() === 'ar' ? 'ar-EG' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' }); }
      catch (e) { txt = d.toDateString(); }
      exp.textContent = txt + '  (' + (days > 0 ? days + ' ' + t('daysLeft') : t('expired')) + ')';
      exp.className = days <= 7 ? 'warn' : '';
    } else {
      exp.textContent = t('unlimited'); exp.className = '';
    }
    $('sb-con').textContent = (u.active_cons || 0) + ' / ' + (u.max_connections || '-');
  }

  /* ---------- continue watching ---------- */
  function cwKey() { return 'cw_' + app.activeId; }

  function onProgress(item, pos, dur, index, playlist) {
    var meta = item && item.meta;
    if (!meta) return;
    var list = load(cwKey(), []).filter(function (c) { return c.key !== meta.key; });
    var done = pos / dur > 0.95;
    if (done && meta.kind === 'series' && index < playlist.length - 1) {
      // finished an episode -> continue from the next one
      list.unshift({ key: meta.key, kind: meta.kind, name: meta.name, img: meta.img, label: playlist[index + 1].meta.label,
        pos: 0, dur: 0, t: Date.now(), playlist: playlist, index: index + 1 });
    } else if (!done && pos > 20) {
      list.unshift({ key: meta.key, kind: meta.kind, name: meta.name, img: meta.img, label: meta.label,
        pos: pos, dur: dur, t: Date.now(), playlist: playlist, index: index });
    }
    save(cwKey(), list.slice(0, 20));
  }

  function resumePos(key, url) {
    var list = load(cwKey(), []);
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      if (c.key === key && c.playlist[c.index] && c.playlist[c.index].url === url) return c.pos;
    }
    return 0;
  }

  // Continue Watching list for the current section (movies or series)
  function continueList() {
    var kind = app.type === 'series' ? 'series' : 'movie';
    return load(cwKey(), []).filter(function (c) { return c.kind === kind; });
  }

  function playContinueEntry(c) {
    if (!c) return;
    show('player', true);
    Player.open(c.playlist, c.index, false, { startAt: c.pos, onProgress: onProgress });
  }

  function removeContinue(i) {
    var c = app.items[i];
    if (!c || app.selectedCat !== '__cw') return;
    var list = load(cwKey(), []).filter(function (x) { return x.key !== c.key; });
    save(cwKey(), list);
    setItems(continueList());
    var cards = $('items').querySelectorAll('.card');
    Nav.reset(cards[Math.min(i, cards.length - 1)] || $('categories').querySelector('.selected'));
  }

  // after coming back from the player / details: refresh Favorites or Continue Watching
  function refreshSpecialList(prevFocus) {
    var idx = prevFocus && prevFocus.getAttribute ? parseInt(prevFocus.getAttribute('data-i'), 10) : -1;
    setItems(app.selectedCat === '__cw' ? continueList() : load(favKey(), []));
    var cards = $('items').querySelectorAll('.card');
    if (idx >= 0 && cards.length) Nav.focus(cards[Math.min(idx, cards.length - 1)]);
    else Nav.reset($('categories').querySelector('.selected'));
  }

  /* ---------- browse (cached + lazy images = fast) ---------- */
  var LIGHT = !!window.tizen || /Web0S|webOS|Tizen/i.test(navigator.userAgent); // older TVs: no big prefetch

  function favKey() { return 'fav_' + app.activeId + '_' + app.type; }
  function cacheFor(type) {
    if (!app.cache[type]) app.cache[type] = { cats: null, all: null, allPromise: null, byCat: {} };
    return app.cache[type];
  }

  // download the whole list once in the background, then every category opens instantly
  function prefetchAll(type) {
    var c = cacheFor(type);
    if (c.all || c.allPromise || LIGHT) return c.allPromise;
    c.allPromise = XtreamAPI.getItems(type, '').then(function (a) { c.all = a; return a; },
      function (e) { c.allPromise = null; throw e; });
    c.allPromise.then(null, function () {});
    return c.allPromise;
  }

  function inCat(x, cat) {
    if (String(x.category_id) === cat) return true;
    var ids = x.category_ids;
    if (ids && ids.length) for (var i = 0; i < ids.length; i++) if (String(ids[i]) === cat) return true;
    return false;
  }

  function getList(type, cat) {
    var c = cacheFor(type);
    if (c.all) {
      if (!cat) return Promise.resolve(c.all);
      return Promise.resolve(c.all.filter(function (x) { return inCat(x, cat); }));
    }
    if (c.byCat[cat]) return Promise.resolve(c.byCat[cat]);
    if (!cat && c.allPromise) return c.allPromise;
    return XtreamAPI.getItems(type, cat).then(function (a) { c.byCat[cat] = a; return a; });
  }

  function openSection(type) {
    app.type = type;
    $('search-box').value = '';
    $('categories').innerHTML = '';
    $('items').innerHTML = '';
    show('browse', true);
    var c = cacheFor(type);
    var catsP = c.cats ? Promise.resolve(c.cats) : XtreamAPI.getCategories(type);
    if (!c.cats) itemsLoading(true);
    prefetchAll(type);
    catsP.then(function (cats) {
      c.cats = cats;
      if (app.screen !== 'browse' || app.type !== type) return;
      var html = '';
      html += '<div class="cat focusable" data-id="__fav" data-i18n="favorites" data-ico="★ ">★ ' + t('favorites') + '</div>';
      if (type !== 'live') html += '<div class="cat focusable" data-id="__cw" data-i18n="continue" data-ico="⟳ ">⟳ ' + t('continue') + '</div>';
      html += '<div class="cat focusable" data-id="" data-i18n="all">' + t('all') + '</div>';
      for (var i = 0; i < cats.length; i++) {
        html += '<div class="cat focusable" data-id="' + esc(cats[i].category_id) + '">' + esc(cats[i].category_name) + '</div>';
      }
      $('categories').innerHTML = html;
      var list = $('categories').querySelectorAll('.cat');
      var first = list[type === 'live' ? 2 : 3] || list[list.length - 1];
      Nav.reset(first);
      selectCategory(first, false);
    }, function (e) { itemsLoading(false); toast(errText(e)); });
  }

  function itemsLoading(on) { $('items-loading').className = 'spinner' + (on ? ' show' : ''); }

  function selectCategory(catEl, focusFirst) {
    if (!catEl) return;
    var sel = $('categories').querySelectorAll('.selected');
    for (var i = 0; i < sel.length; i++) sel[i].className = sel[i].className.replace(' selected', '');
    catEl.className += ' selected';
    var cat = catEl.getAttribute('data-id');
    app.selectedCat = cat;
    $('search-box').value = '';
    var token = ++app.req, type = app.type;
    if (cat === '__fav') { itemsLoading(false); setItems(load(favKey(), []), focusFirst && catEl); return; }
    if (cat === '__cw') { itemsLoading(false); setItems(continueList(), focusFirst && catEl); return; }
    $('items').innerHTML = '';
    itemsLoading(true);
    getList(type, cat).then(function (items) {
      if (token !== app.req) return; // user already picked another category
      itemsLoading(false);
      setItems(items, focusFirst && catEl);
    }, function (e) { if (token === app.req) { itemsLoading(false); toast(errText(e)); } });
  }

  function setItems(items, focusFrom) {
    app.allItems = items;
    filterItems('');
    if (focusFrom && Nav.current() === focusFrom) {
      var f = $('items').querySelector('.card');
      if (f) Nav.focus(f);
    }
  }

  var searchT;
  function onSearch(q) {
    clearTimeout(searchT);
    searchT = setTimeout(function () { filterItems(q); }, 180);
  }

  function filterItems(q) {
    q = (q || '').toLowerCase();
    var all = app.allItems, out = [];
    if (!q) out = all;
    else for (var i = 0; i < all.length; i++) if (String(all[i].name || '').toLowerCase().indexOf(q) !== -1) out.push(all[i]);
    app.items = out; app.rendered = 0;
    if (lazyObs) lazyObs.disconnect();
    $('items').innerHTML = out.length ? '' : '<div class="empty">' + t(q ? 'noResults' : 'empty') + '</div>';
    $('items').scrollTop = 0;
    renderMore();
    updateCounter(null);
  }

  // thumbnails load only when they come into view
  var lazyObs = null;
  if (window.IntersectionObserver) {
    lazyObs = new IntersectionObserver(function (entries) {
      for (var i = 0; i < entries.length; i++) {
        if (!entries[i].isIntersecting) continue;
        var el = entries[i].target, u = el.getAttribute('data-bg');
        if (u) { el.style.backgroundImage = 'url("' + u.replace(/"/g, '%22') + '")'; el.removeAttribute('data-bg'); }
        lazyObs.unobserve(el);
      }
    }, { root: $('items'), rootMargin: '600px 0px' });
  }

  function renderMore() {
    var box = $('items'), end = Math.min(app.items.length, app.rendered + CHUNK), html = '';
    var favs = load(favKey(), []), favSet = {};
    for (var f = 0; f < favs.length; f++) favSet[itemKey(favs[f])] = 1;
    var cw = app.selectedCat === '__cw';
    for (var i = app.rendered; i < end; i++) {
      var it = app.items[i], img = cw ? it.img : (it.stream_icon || it.cover || '');
      var bg = img ? (lazyObs ? ' data-bg="' + esc(img) + '"' : bgUrl(img)) : '';
      var bar = '', name = esc(it.name);
      if (cw) {
        var pct = it.dur ? Math.round(it.pos / it.dur * 100) : 0;
        bar = '<div class="bar"><div style="width:' + pct + '%"></div></div>';
        if (it.label) name += '  ·  ' + esc(it.label);
      } else if (favSet[itemKey(it)]) {
        name = '<span class="fav-star">★</span> ' + name;
      }
      html += '<div class="card focusable ' + app.type + '" data-i="' + i + '">' +
        '<div class="thumb"' + bg + '>' + (img ? '' : ICON[app.type]) + bar + '</div>' +
        '<div class="name">' + name + '</div></div>';
    }
    var tmp = document.createElement('div'); tmp.innerHTML = html;
    var frag = document.createDocumentFragment(), thumbs = [];
    while (tmp.firstChild) {
      var node = tmp.firstChild;
      if (lazyObs && node.firstChild && node.firstChild.getAttribute && node.firstChild.getAttribute('data-bg')) thumbs.push(node.firstChild);
      frag.appendChild(node);
    }
    box.appendChild(frag);
    for (var j = 0; j < thumbs.length; j++) lazyObs.observe(thumbs[j]);
    app.rendered = end;
  }

  function itemKey(it) { return String(it.stream_id || it.series_id); }
  function isFavItem(it) {
    var f = load(favKey(), []), k = itemKey(it);
    for (var i = 0; i < f.length; i++) if (itemKey(f[i]) === k) return true;
    return false;
  }
  function toggleFav(it) {
    var f = load(favKey(), []), k = itemKey(it), found = -1;
    for (var i = 0; i < f.length; i++) if (itemKey(f[i]) === k) found = i;
    if (found >= 0) { f.splice(found, 1); toast(t('favRemoved')); }
    else { f.unshift(it); toast(t('favAdded')); }
    save(favKey(), f);
    return found < 0;
  }

  /* ---------- open item ---------- */
  function openItem(index) {
    var it = app.items[index];
    if (!it) return;
    if (app.selectedCat === '__cw') { playContinueEntry(it); return; }
    if (app.type === 'live') {
      var list = [];
      for (var i = 0; i < app.items.length; i++) {
        list.push({
          title: app.items[i].name,
          url: XtreamAPI.liveUrl(app.items[i].stream_id, 'm3u8'),
          fallback: XtreamAPI.liveUrl(app.items[i].stream_id, 'ts')
        });
      }
      show('player', true);
      Player.open(list, index, true);
    } else if (app.type === 'movie') {
      openMovie(it);
    } else {
      openSeries(it);
    }
  }

  function setPoster(el, url) { el.style.backgroundImage = url ? 'url("' + String(url).replace(/"/g, '%22') + '")' : ''; }
  function fmtTime(s) {
    s = Math.floor(s); var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return (h ? h + ':' : '') + (m < 10 ? '0' : '') + m + ':' + (x < 10 ? '0' : '') + x;
  }
  function metaLine(parts) {
    var out = [];
    for (var i = 0; i < parts.length; i++) if (parts[i]) out.push(esc(parts[i]));
    return out.join('  ·  ');
  }

  /* --- movie details --- */
  function openMovie(it) {
    var m = {
      it: it, key: 'm' + it.stream_id, name: it.name, img: it.stream_icon || '',
      url: XtreamAPI.movieUrl(it.stream_id, it.container_extension),
      fallback: XtreamAPI.movieUrl(it.stream_id, 'm3u8')
    };
    app.movie = m;
    $('movie-name').textContent = it.name;
    setPoster($('movie-poster'), m.img);
    $('movie-meta').innerHTML = it.rating ? '★ ' + esc(it.rating) : '';
    $('movie-plot').textContent = '';
    $('movie-extra').innerHTML = '';
    show('movie', true);
    refreshMovieButtons();
    Nav.reset($('btn-resume').style.display !== 'none' ? $('btn-resume') : $('btn-play'));

    XtreamAPI.getVodInfo(it.stream_id).then(function (res) {
      if (app.movie !== m) return;
      var info = (res && res.info) || {}, data = (res && res.movie_data) || {};
      if (data.container_extension && data.container_extension !== it.container_extension) {
        m.url = XtreamAPI.movieUrl(it.stream_id, data.container_extension);
      }
      var year = String(info.releasedate || info.release_date || info.year || '').substring(0, 4);
      $('movie-meta').innerHTML = metaLine([year, info.duration, info.genre, info.rating ? '★ ' + info.rating : (it.rating ? '★ ' + it.rating : '')]);
      $('movie-plot').textContent = info.plot || info.description || '';
      var extra = '';
      if (info.director) extra += '<div><b>' + t('director') + ':</b> ' + esc(info.director) + '</div>';
      if (info.cast || info.actors) extra += '<div><b>' + t('cast') + ':</b> ' + esc(info.cast || info.actors) + '</div>';
      $('movie-extra').innerHTML = extra;
      var big = info.movie_image || info.cover_big;
      if (big && !m.img) setPoster($('movie-poster'), big);
      refreshMovieButtons();
    }, function () {});
  }

  function refreshSeriesFav() {
    if (!app.series) return;
    $('btn-series-fav').textContent = isFavItem(app.series.it) ? '★ ' + t('inFav') : '☆ ' + t('addFav');
  }

  function refreshMovieButtons() {
    var m = app.movie; if (!m) return;
    var pos = resumePos(m.key, m.url);
    var r = $('btn-resume');
    r.style.display = pos > 0 ? '' : 'none';
    r.textContent = '⟳ ' + t('resume') + '  ' + fmtTime(pos);
    $('play-label').textContent = pos > 0 ? t('fromStart') : t('play');
    $('btn-fav').textContent = isFavItem(m.it) ? '★ ' + t('inFav') : '☆ ' + t('addFav');
  }

  function playMovie(fromPos) {
    var m = app.movie;
    show('player', true);
    Player.open([{ title: m.name, url: m.url, fallback: m.url === m.fallback ? null : m.fallback, meta: { key: m.key, kind: 'movie', name: m.name, img: m.img } }],
      0, false, { startAt: fromPos ? resumePos(m.key, m.url) : 0, onProgress: onProgress });
  }

  /* --- series (info is cached and prefetched while a card is focused) --- */
  var seriesInfo = {};
  function getSeriesInfo(id) {
    if (!seriesInfo[id]) {
      seriesInfo[id] = XtreamAPI.getSeriesInfo(id);
      seriesInfo[id].then(null, function () { delete seriesInfo[id]; });
    }
    return seriesInfo[id];
  }
  var prefetchT;
  function prefetchSeries(it) {
    clearTimeout(prefetchT);
    prefetchT = setTimeout(function () { if (it && it.series_id) getSeriesInfo(it.series_id); }, 350);
  }

  function openSeries(it) {
    // open the screen right away with what we already know, fill the rest when it arrives
    var s = { it: it, id: it.series_id, name: it.name, img: it.cover || '', episodes: {}, seasons: [], current: [] };
    app.series = s;
    $('series-name').textContent = it.name;
    setPoster($('series-cover'), s.img);
    $('series-info').innerHTML = metaLine([String(it.releaseDate || it.year || '').substring(0, 4), it.genre, it.rating ? '★ ' + it.rating : '']);
    $('series-plot').textContent = it.plot || '';
    $('seasons').innerHTML = '';
    $('episodes').innerHTML = '<div class="spinner show inline"></div>';
    refreshSeriesFav();
    show('series', true);
    Nav.reset($('btn-series-fav'));

    getSeriesInfo(it.series_id).then(function (res) {
      if (app.series !== s) return;
      var info = res.info || {};
      var eps = res.episodes || {}, seasons = [];
      for (var k in eps) if (eps.hasOwnProperty(k)) seasons.push(k);
      seasons.sort(function (a, b) { return parseInt(a, 10) - parseInt(b, 10); });
      s.name = info.name || it.name; s.img = info.cover || s.img; s.episodes = eps; s.seasons = seasons;
      $('series-name').textContent = s.name;
      setPoster($('series-cover'), s.img);
      var year = String(info.releaseDate || info.release_date || info.year || '').substring(0, 4);
      $('series-info').innerHTML = metaLine([year, info.genre, info.rating ? '★ ' + info.rating : '']);
      $('series-plot').textContent = info.plot || '';
      if (!seasons.length) { $('episodes').innerHTML = '<div class="empty">' + t('noEpisodes') + '</div>'; return; }
      var html = '';
      for (var i = 0; i < seasons.length; i++)
        html += '<div class="season focusable" data-s="' + esc(seasons[i]) + '">' + t('season') + ' ' + esc(seasons[i]) + '</div>';
      $('seasons').innerHTML = html;
      // open the season of the episode you were watching
      var first = $('seasons').firstChild, cw = load(cwKey(), []);
      for (var c = 0; c < cw.length; c++) if (cw[c].key === 's' + s.id && cw[c].label) {
        var m = /^S(\S+) /.exec(cw[c].label);
        var el = m && $('seasons').querySelector('[data-s="' + m[1] + '"]');
        if (el) first = el;
      }
      selectSeason(first);
      if (app.screen === 'series' && Nav.current() === $('btn-series-fav')) Nav.reset(first);
    }, function (e) { if (app.series === s) { $('episodes').innerHTML = ''; toast(errText(e)); } });
  }

  function selectSeason(sEl) {
    var sel = $('seasons').querySelectorAll('.selected');
    for (var i = 0; i < sel.length; i++) sel[i].className = sel[i].className.replace(' selected', '');
    sEl.className += ' selected';
    var season = sEl.getAttribute('data-s');
    var list = XtreamAPI.toArray(app.series.episodes[season]);
    app.series.season = season;
    app.series.current = list;
    var html = '';
    for (var j = 0; j < list.length; j++) {
      var num = list[j].episode_num || (j + 1);
      html += '<div class="episode focusable" data-e="' + j + '"><span>' + esc('E' + num + (list[j].title ? '  ·  ' + list[j].title : '')) + '</span></div>';
    }
    $('episodes').innerHTML = html;
    $('episodes').scrollTop = 0;
  }

  function playEpisode(index) {
    var s = app.series, eps = s.current, list = [], key = 's' + s.id;
    for (var i = 0; i < eps.length; i++) {
      var label = 'S' + s.season + ' E' + (eps[i].episode_num || (i + 1));
      list.push({
        title: s.name + '  ·  ' + label + (eps[i].title ? '  ·  ' + eps[i].title : ''),
        url: XtreamAPI.episodeUrl(eps[i].id, eps[i].container_extension),
        fallback: (eps[i].container_extension || 'mp4') === 'm3u8' ? null : XtreamAPI.episodeUrl(eps[i].id, 'm3u8'),
        meta: { key: key, kind: 'series', name: s.name, img: s.img, label: label }
      });
    }
    show('player', true);
    Player.open(list, index, false, { startAt: resumePos(key, list[index].url), onProgress: onProgress });
  }

  /* ---------- language ---------- */
  function toggleLang() {
    Lang.toggle();
    $('bar-title').textContent = TITLES[app.screen] ? TITLES[app.screen]() : '';
    var cats = $('categories').querySelectorAll('[data-i18n]');
    for (var i = 0; i < cats.length; i++) cats[i].textContent = (cats[i].getAttribute('data-ico') || '') + t(cats[i].getAttribute('data-i18n'));
    refreshSeriesFav();
    var ss = $('seasons').querySelectorAll('.season');
    for (i = 0; i < ss.length; i++) ss[i].textContent = t('season') + ' ' + ss[i].getAttribute('data-s');
    renderStatus();
    if (app.screen === 'movie') refreshMovieButtons();
    if (app.screen === 'servers') { renderServers(); Nav.reset($('btn-lang')); }
    else Nav.focus($('btn-lang'));
  }

  /* ---------- OK / click ---------- */
  function activate(el) {
    if (!el) return;
    var c = el.className, id = el.id;
    if (el.getAttribute('data-dlg') !== null) dialogPick(el.getAttribute('data-dlg'));
    else if (el.getAttribute('data-act')) Player.action(el.getAttribute('data-act'));
    else if (id === 'btn-ext') Player.openExternal();
    else if (id === 'btn-home') goHome();
    else if (id === 'btn-back' || id === 'btn-player-back') back();
    else if (id === 'btn-servers') { if (app.screen !== 'servers') openServers(); }
    else if (id === 'btn-lang') toggleLang();
    else if (id === 'btn-save') saveServer();
    else if (id === 'btn-add') openAdd();
    else if (id === 'btn-pair' || id === 'btn-pair-new') openPair();
    else if (id === 'btn-play') playMovie(false);
    else if (id === 'btn-resume') playMovie(true);
    else if (id === 'btn-fav') { toggleFav(app.movie.it); refreshMovieButtons(); }
    else if (id === 'btn-series-fav') { toggleFav(app.series.it); refreshSeriesFav(); }
    else if (c.indexOf('connect') !== -1) {
      var sid = el.getAttribute('data-id');
      for (var i = 0; i < app.servers.length; i++) if (app.servers[i].id === sid) connect(app.servers[i]);
    }
    else if (id === 'btn-del-server') askDeleteServer();
    else if (c.indexOf('tile') !== -1) openSection(el.getAttribute('data-type'));
    else if (c.indexOf('cat') !== -1) selectCategory(el, true);
    else if (c.indexOf('card') !== -1) openItem(parseInt(el.getAttribute('data-i'), 10));
    else if (c.indexOf('season') !== -1) { selectSeason(el); var e = $('episodes').firstChild; if (e) Nav.focus(e); }
    else if (c.indexOf('episode') !== -1) playEpisode(parseInt(el.getAttribute('data-e'), 10));
    else if (el.tagName === 'INPUT') {
      // first OK opens the on-screen keyboard, OK from the keyboard closes it and moves down
      if (document.activeElement === el) { el.blur(); Nav.move('down'); }
      else el.focus();
    }
  }

  // pressing DOWN at the end of a list goes back to its first item
  Nav.onListEnd = function (dir, el) {
    if (dir !== 'down') return false;
    var list = el.parentNode;
    if (list.id === 'items') {
      if (app.rendered < app.items.length) { renderMore(); Nav.move('down'); return true; }
      var firstCard = list.querySelector('.card');
      if (firstCard && firstCard !== el) { list.scrollTop = 0; Nav.focus(firstCard); toast(t('backToTop')); return true; }
      return true;
    }
    if (list.id === 'categories' || list.id === 'episodes') {
      var first = list.querySelector('.focusable');
      if (first && first !== el) { list.scrollTop = 0; Nav.focus(first); toast(t('backToTop')); }
      return true;
    }
    return false;
  };

  function updateCounter(el) {
    var c = $('items-count');
    if (el && el.className.indexOf('card') !== -1 && app.items.length) {
      c.textContent = (parseInt(el.getAttribute('data-i'), 10) + 1) + ' / ' + app.items.length;
      c.className = 'items-count show';
    } else if (app.screen === 'browse') {
      c.textContent = app.items.length ? app.items.length + '' : '';
      c.className = 'items-count' + (app.items.length ? ' show' : '');
    }
  }

  Nav.onFocus = function (el) {
    updateCounter(el);
    if (el.className.indexOf('card') !== -1) {
      var i = parseInt(el.getAttribute('data-i'), 10);
      if (app.type === 'series' && app.selectedCat !== '__cw') prefetchSeries(app.items[i]);
      if (i >= app.rendered - 12 && app.rendered < app.items.length) renderMore();
    }
  };

  /* ---------- remote ---------- */
  document.addEventListener('keydown', function (e) {
    var code = e.keyCode;
    var inInput = document.activeElement && document.activeElement.tagName === 'INPUT';
    var isBack = code === Keys.BACK_TIZEN || code === Keys.BACK_WEBOS || code === Keys.ESC ||
      (code === Keys.BACKSPACE && !inInput);

    if (dlg) {
      e.preventDefault();
      if (isBack) closeDialog();
      else if (code === Keys.LEFT) Nav.move('left');
      else if (code === Keys.RIGHT) Nav.move('right');
      else if (code === Keys.UP) Nav.move('up');
      else if (code === Keys.DOWN) Nav.move('down');
      else if (code === Keys.ENTER) activate(Nav.current());
      return;
    }
    if (isBack) { e.preventDefault(); back(); return; }

    if (app.screen === 'player') {
      if (Player.handleKey(code)) e.preventDefault();
      return;
    }

    // red button: favorites (browse) / remove from continue watching (home)
    if (code === 403) {
      var cur = Nav.current();
      if (!cur) return;
      if (cur.className.indexOf('card') !== -1) {
        var ci = parseInt(cur.getAttribute('data-i'), 10);
        if (app.selectedCat === '__cw') removeContinue(ci);
        else { toggleFav(app.items[ci]); if (app.selectedCat === '__fav') refreshSpecialList(cur); }
      } else if (app.screen === 'series' && app.series) {
        toggleFav(app.series.it); refreshSeriesFav();
      }
      return;
    }

    switch (code) {
      case Keys.LEFT: if (!inInput || !e.target.value) { e.preventDefault(); Nav.move('left'); } break;
      case Keys.RIGHT: if (!inInput || !e.target.value) { e.preventDefault(); Nav.move('right'); } break;
      case Keys.UP: e.preventDefault(); Nav.move('up'); break;
      case Keys.DOWN: e.preventDefault(); Nav.move('down'); break;
      case Keys.ENTER: e.preventDefault(); activate(Nav.current()); break;
    }
  });

  // mouse / LG magic remote
  function focusableFrom(t) {
    while (t && t !== document.body && (!t.className || String(t.className).indexOf('focusable') === -1)) t = t.parentNode;
    return t && t !== document.body ? t : null;
  }
  document.addEventListener('click', function (e) {
    var el = focusableFrom(e.target);
    if (!el) return;
    Nav.focus(el);
    if (el.tagName === 'INPUT') el.focus(); else activate(el);
  });
  // LG Magic Remote: when a list scrolls under the (hidden) pointer the browser fires mouseover
  // without the pointer moving -> only follow the mouse when it really moved
  var lastMouseMove = 0, lastKey = 0, lastMX = -1, lastMY = -1;
  document.addEventListener('mousemove', function (e) {
    if (e.clientX === lastMX && e.clientY === lastMY) return;
    lastMX = e.clientX; lastMY = e.clientY; lastMouseMove = Date.now();
  });
  document.addEventListener('keydown', function () { lastKey = Date.now(); }, true);
  document.addEventListener('mouseover', function (e) {
    var now = Date.now();
    if (now - lastMouseMove > 200 || now - lastKey < 700) return;
    var el = focusableFrom(e.target);
    if (el && el !== Nav.current() && el.tagName !== 'INPUT' && app.screen !== 'player') Nav.focus(el);
  });

  $('search-box').addEventListener('input', function () { onSearch(this.value); });
  window.addEventListener('popstate', function () { back(); });

  // small API for pc.js
  window.App = {
    back: back,
    screen: function () { return app.screen; },
    loadMore: function () { if (app.screen === 'browse' && app.rendered < app.items.length) renderMore(); },
    removeContinue: removeContinue
  };

  /* ---------- start ---------- */
  Lang.apply();
  Player.init();
  Player.setDefaultStop(function () { back(); });

  app.servers = load('servers', []);
  var old = load('creds', null); // migrate from the first version
  if (old && old.url && !app.servers.length) {
    app.servers.push({ id: 's' + Date.now(), url: old.url, user: old.user, pass: old.pass, name: '' });
    save('servers', app.servers);
    try { localStorage.removeItem('creds'); } catch (e) {}
  }
  app.activeId = load('active', null);
  var active = activeServer() || app.servers[0];

  if (active) connect(active, true);
  else openAdd();
})();
