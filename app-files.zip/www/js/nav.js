/* تنقل بالريموت (D-pad) — بيختار أقرب عنصر في الاتجاه */
var Keys = {
  LEFT: 37, UP: 38, RIGHT: 39, DOWN: 40, ENTER: 13,
  BACK_TIZEN: 10009, BACK_WEBOS: 461, BACKSPACE: 8, ESC: 27,
  PLAY: 415, PAUSE: 19, PLAY_PAUSE: 10252, STOP: 413, FF: 417, RW: 412,
  CH_UP: 427, CH_DOWN: 428, PAGE_UP: 33, PAGE_DOWN: 34
};

(function registerTizenKeys() {
  try {
    if (window.tizen && tizen.tvinputdevice) {
      var keys = ['MediaPlay', 'MediaPause', 'MediaPlayPause', 'MediaStop', 'MediaFastForward',
        'MediaRewind', 'ChannelUp', 'ChannelDown', 'ColorF0Red', 'ColorF1Green'];
      for (var i = 0; i < keys.length; i++) { try { tizen.tvinputdevice.registerKey(keys[i]); } catch (e) {} }
    }
  } catch (e) {}
})();

/* Older TV browsers (webOS / Tizen before Chrome 84) don't support flexbox "gap" -> use margins instead */
(function detectFlexGap() {
  var d = document.createElement('div');
  d.style.cssText = 'display:flex;flex-direction:column;row-gap:1px;position:absolute;visibility:hidden';
  d.appendChild(document.createElement('div')); d.appendChild(document.createElement('div'));
  document.documentElement.appendChild(d);
  var ok = d.scrollHeight === 1;
  d.parentNode.removeChild(d);
  if (!ok) document.documentElement.className += ' nogap';
})();

var Nav = (function () {
  var current = null;

  function visible(el) {
    if (!el.offsetParent && el.style.position !== 'fixed') return false;
    var screen = el.closest ? el.closest('.screen') : null;
    return !screen || screen.className.indexOf('active') !== -1;
  }

  function candidates() {
    var dialog = document.getElementById('dialog');
    var all = dialog && dialog.className.indexOf('hidden') === -1
      ? dialog.querySelectorAll('.focusable')
      : document.querySelectorAll('.screen.active .focusable, #topbar .focusable');
    var out = [];
    for (var i = 0; i < all.length; i++) if (visible(all[i])) out.push(all[i]);
    return out;
  }

  function focus(el) {
    if (!el) return;
    if (Nav.touch) { current = el; return; } // phones/tablets: no focus highlight
    if (current) current.className = current.className.replace(/\s*focused/g, '');
    current = el;
    el.className += ' focused';
    if (document.activeElement && document.activeElement !== el && document.activeElement.blur) document.activeElement.blur();
    // على الكمبيوتر الكيبورد موجود، فنكتب في الخانة على طول
    if (el.tagName === 'INPUT' && document.body.className.indexOf('pc') !== -1) el.focus();
    scrollIntoParent(el);
    if (Nav.onFocus) Nav.onFocus(el);
  }

  // تمرير الحاوية عشان العنصر يفضل ظاهر
  function scrollIntoParent(el) {
    var p = el.parentNode;
    while (p && p !== document.body) {
      if (p.scrollHeight > p.clientHeight + 2) {
        var top = el.offsetTop - p.offsetTop;
        if (top < p.scrollTop + 10) p.scrollTop = Math.max(0, top - 20);
        else if (top + el.offsetHeight > p.scrollTop + p.clientHeight - 10)
          p.scrollTop = top + el.offsetHeight - p.clientHeight + 20;
        return;
      }
      p = p.parentNode;
    }
  }

  function move(dir) {
    var list = candidates();
    if (!list.length) return;
    if (!current || list.indexOf(current) === -1) { focus(list[0]); return; }
    var r = current.getBoundingClientRect();
    var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    // first look inside the same list (so long lists scroll to the end), then anywhere on screen
    var best = pick(list, dir, r, cx, cy, current.parentNode);
    // end of a list: let the app decide (wrap to the top) instead of jumping to another panel
    if (!best && Nav.onListEnd && Nav.onListEnd(dir, current)) return;
    if (!best) best = pick(list, dir, r, cx, cy, null);
    if (best) focus(best);
    else if (Nav.onEdge) Nav.onEdge(dir, current);
  }

  function pick(list, dir, r, cx, cy, sameParent) {
    var best = null, bestScore = Infinity;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el === current) continue;
      if (sameParent && el.parentNode !== sameParent) continue;
      var b = el.getBoundingClientRect();
      var x = b.left + b.width / 2, y = b.top + b.height / 2;
      var dx = x - cx, dy = y - cy, main, cross;
      // compare centers (the focused element is scaled up, so its edges overlap its neighbours)
      if (dir === 'left') { if (dx > -10 || Math.abs(dx) < Math.abs(dy) * 0.3 && b.right > r.left + r.width / 2) continue; main = -dx; cross = Math.abs(dy); }
      else if (dir === 'right') { if (dx < 10 || Math.abs(dx) < Math.abs(dy) * 0.3 && b.left < r.right - r.width / 2) continue; main = dx; cross = Math.abs(dy); }
      else if (dir === 'up') { if (dy > -10 || Math.abs(dy) < Math.abs(dx) * 0.3 && b.bottom > r.top + r.height / 2) continue; main = -dy; cross = Math.abs(dx); }
      else { if (dy < 10 || Math.abs(dy) < Math.abs(dx) * 0.3 && b.top < r.bottom - r.height / 2) continue; main = dy; cross = Math.abs(dx); }
      var score = main + cross * 2.5;
      if (el.parentNode === current.parentNode) score -= 50;
      if (score < bestScore) { bestScore = score; best = el; }
    }
    return best;
  }

  return {
    focus: focus,
    move: move,
    current: function () { return current; },
    reset: function (el) {
      var old = document.querySelectorAll('.focused');
      for (var i = 0; i < old.length; i++) old[i].className = old[i].className.replace(/\s*focused/g, '');
      current = null;
      focus(el || candidates()[0]);
    },
    onFocus: null,
    onListEnd: null,
    onEdge: null
  };
})();
