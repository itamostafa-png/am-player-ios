/* Phones & tablets: responsive layout, touch scrolling, native video controls.
   Not used on Samsung/LG TVs, Android TV boxes or the Windows app. */
(function () {
  var ua = navigator.userAgent;
  var isTVPlatform = !!window.tizen || /Web0S|webOS|Tizen/i.test(ua);
  var isAndroidTV = false;
  try { isAndroidTV = !!(window.AndroidApp && AndroidApp.isTV()); } catch (e) {}
  var isElectron = /Electron/i.test(ua);
  var touch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
  if (isTVPlatform || isAndroidTV || isElectron || !touch) return;

  window.IS_MOBILE = true;
  document.documentElement.className += ' mobile';
  document.body.className += ' mobile';
  Nav.touch = true;

  var vp = document.querySelector('meta[name=viewport]');
  vp.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover');

  // load more cards while scrolling
  var items = document.getElementById('items');
  items.addEventListener('scroll', function () {
    if (items.scrollTop + items.clientHeight > items.scrollHeight - 800) App.loadMore();
  });

  // our own player controls; tap the video to show / hide them
  var video = document.getElementById('video');
  video.setAttribute('playsinline', '');
  video.setAttribute('webkit-playsinline', '');
  video.addEventListener('click', function () {
    if (Player.osdVisible()) Player.hideOsd(); else Player.showOsd(false);
  });
})();
